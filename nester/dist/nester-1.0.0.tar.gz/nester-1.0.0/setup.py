from distutils.core import setup

setup(
    name        = 'nester',
    version     = '1.0.0',
    py_modules  = ['nester'],
    author      = 'Jonas',
    author_email= "kingdom2232@sina.com",
    url         = '',
    description = "A simple printer for nested lists"
)